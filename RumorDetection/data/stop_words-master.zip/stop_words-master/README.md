# stop_words
中文和英文停用词词表

```shell
python combine.py #汇总停用词
```

- chinese.txt 汇总chinese目录下全部停用词
- english.txt 汇总english目录下全部停用词

